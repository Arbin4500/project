<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
<div>
        <form action="" method="post">
        <h1><span style="color:blue;">उडान</span> <span style="color:red;">Sewa</span></h1>
        <h2 style="text-align:center">Support No:+97798232343 </h2>
        <h2 style="text-align:center">Sign Up Form</h2>  
        <br>
           
<!-- <label for="un">Username:</label> -->
<label for="">Compnay Name*</label><br>
<input type="text" name='un' id='reg' placeholder="Company Name"> 
<br>

<label for="">Full Name*</label><br>
<input type="text" name='fn' id='reg' placeholder="Full Name"> 
<br>

<label for="">Address*</label><br>
<input type="text" name='un' id='reg' placeholder="Address"> 
<br>
<label for="">Country*</label><br>
<input type="text" name='un' id='reg' placeholder="Country"> 
<br>
<label for="">City*</label><br>
<input type="text" name='un' id='reg' placeholder="City"> 
<br>
<label for="">Email*</label><br>
<input type="text" name='un' id='reg' placeholder="Email"> 
<br>


        </form>
    </div>
</body>
</html>