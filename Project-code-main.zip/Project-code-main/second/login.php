<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
   <link rel="stylesheet" href="style.css">
</head>
<body>
    <div>
        <form action="" method="post">
        <h1><span style="color:blue;">उडान</span> <span style="color:red;">Sewa</span></h1>
            
<!-- <label for="un">Username:</label> -->
<input type="text" name='un' id='un' placeholder="Username"> 
    <br>
    <br>
<!-- <label for="">Password</label> -->
    <input type="password" name='pass' placeholder="Password">
    <br>
    <br><input type="submit" name="sub" value='Agent Login' id="btn" >
    <br> <br>
    <label for="">Not an account?<a href="register.php">Register Now</a></label>
    

        </form>
    </div>
</body>
</html>