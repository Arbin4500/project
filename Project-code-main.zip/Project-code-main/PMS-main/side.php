
<div class="sidebar">
      
      <a href="homepage.php" class = 'vis'><i class="fas fa-home"></i><span>Home</span></a>
      <a href="Doctorsign.php" class = 'vis'><i class='fas fa-user-md'></i><span>Doctor</span></a>
      <a href="Drugsign.php" class = 'vis'><i class='fas fa-pills'></i><span>Drugs</span></a>
      <a href="patient.php" class = 'vis'><i class='fas fa-male'></i><span>Patient</span></a>
      <a href="delete.php" class = 'vis'><i class='fas fa-male'></i><span>Delete</span></a>
      <!-- <a href="employee.php"><i class='fas fa-user-nurse'></i><span>Employee</span></a> -->

        <!-- <a href="pharmacy.php"><i class='fas fa-hospital-symbol'></i><span>Pharmacy</span></a> -->
<a href="#"><i class="fas fa-question-circle"></i><span>Help</span></a>

</div>