<?php
$conn = mysqli_connect("localhost","root","","pharmacy2");
if(!$conn){
  die("Connection to the database lost...".mysqli_connect_error());
}
if(isset($_POST['submit'])){
  $iid=rand(10,100);
  $name = $_POST['name'];
  $manuf = $_POST['manuf'];
  $exp = (int)$_POST['exp'];
  $sql = "SELECT * FROM drug WHERE drug_name = '$name'";
  $res = mysqli_query($conn,$sql);
    if(mysqli_num_rows($res)){
    echo"<script type = 'text/javascript'> 
      alert('Drug name already exists...');</script>";
  }
  else{
    $sql = "INSERT INTO drug (drug_id,drug_name,manufacturer,expiry_age) VALUES ($iid,'$name','$manuf','$exp')";
    if(mysqli_query($conn,$sql)){
      echo"<script type = 'text/javascript'> 
      alert('Given Details have been added successfully...');</script>";
      header("location:Drugsign.php");
    }
    else{
      echo"<script type = 'text/javascript'> 
      alert('Failed to enter given details...');</script>";
    }
      }
}
$res = mysqli_query($conn,"SELECT * FROM drug");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <?php include "header.php"?>

  
    <?php

include "side.php";
session_start();
$decide=$_SESSION["token"];
?>  
  <!--sidebar end-->   
    <div class="content" id='doc'>
      <div class='incontent'>
        <div class='inside'>
        <div class='top'><button class='but'><a href='homepage.php'>Back</a></button></div>
        <hr>
        <div class='fcontain'>
        <div class='fcontain' id="form2">
          <center>
          <form class = 'form' method = 'post' action = 'Drugsign.php'>

        <div class='fdiv'><input name = 'name' class='in fin' placeholder='Drug Name' type='text' required></div>
        <div class='fdiv'><input class='in fin' name = 'manuf' placeholder='Manufactured by' type='text' required></div>
       <div class='fdiv'><input class='in fin' placeholder = 'Expiry Date in Months' name = 'exp' type='number' required></div>
        <input type = 'submit' name = 'submit' class = 'reg' value = 'Add'><br>
        </form><br><br>
</div>
       <center> <input type="search" placeholder="Search" class="inBox2" id="searchInpu" style="color:#000;padding:10px;"><button style="background-color:#000;padding:10px;" class="clear2" id="clear">clear</button></center>

       
        <section>
        <h1><center>DRUG DETAILS</center></h1>
        <table class="maintable" id="contentDisplay" style="visibility:hidden;">
           <thead>
             <tr>
             <th>Drug ID</th>
            <th>Drug Name</th>
            <th>Manufacturer</th>
            <th>Expiry Date</th>
             </tr>
             <tr>
               
             </tr>
           </thead>
          </table>
          <p id="error" style="color:gray;text-align:center;font-size:20px;"></p>
        <table class='maintable' id="edit2">
          <tr>
            <th>Drug ID</th>
            <th>Drug Name</th>
            <th>Manufacturer</th>
            <th>Expiry Date</th>
          </tr>
          <?php 
           if($res)
            while($rows = mysqli_fetch_assoc($res)){
              ?>
          <tr>
            <td><?php echo $rows['drug_id'];?></td>
            <td><?php echo $rows['drug_name'];?></td>
            <td><?php echo $rows['manufacturer'];?></td>
            <td><?php echo $rows['expiry_age'].' months';?></td>
          
           
          </tr>
          <?php } ?>
        </table></section>
        </center>
        <br>
        </div>   </div>  </div>   
    </div>
    <script src="javascript/onclick.js"></script>

    <?php
    if($decide==1){
  echo '<script type="text/javascript>
  let sidebar=document.getElementsByClassName("sidebar");
  let visi=document.getElementById("visi");
visi.style.display="block";
for(let i=0;i<6;i++){
  sidebar[0].children[i].style.display="inline-block";
}</script>';
}
else if($decide==2){
 echo '<script type="text/javascript" src="javascript/none.js">

</script>';
echo '<script type="text/javascript">
let form=document.getElementById("form2");
form.style.display="none";
</script>';
}
else if($decide==3){
  echo '<script type="text/javascript" src="javascript/none2.js">
</script>';
}
?>
  </body>

  </html>
