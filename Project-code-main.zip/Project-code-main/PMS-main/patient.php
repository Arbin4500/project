<?php
$conn = mysqli_connect("localhost","root","","pharmacy2");
if(!$conn){
  die("Connection to the database lost...".mysqli_connect_error());
}
if(isset($_POST['submit'])){
  $iid=rand(10,100);
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $phone = (int)$_POST['phone'];
  $addr = $_POST['address'];
  $sex = $_POST['gender'];
  $doctorid = (int)$_POST['doctor_id'];
  $sql = "SELECT * FROM patient WHERE (patient_id=$iid)";
  $res = mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)){
    echo"<script type = 'text/javascript'> 
      alert('Username already exists...');</script>";
  }
  else{
    $sql = "INSERT INTO patient (patient_id,first_name,last_name,gender,address,phone_no,doctor_id) VALUES ($iid,'$fname','$lname','$sex','$addr','$phone','$doctorid')";
    if(mysqli_query($conn,$sql)){
      $pass=rand(100,999)."£%".rand(100,999);
       $sql = "INSERT INTO patient_log(id,patient_id,password) VALUES (null,$iid,'$pass')";
mysqli_query($conn,$sql);
      echo"<script type = 'text/javascript'> 
      alert('Given Details have been added successfully...');</script>";
      header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/patient.php");
    }
    else{
      echo"<script type = 'text/javascript'> 
      alert('Failed to enter given details...');</script>";
    }
  }
}
$res = mysqli_query($conn,"SELECT * FROM patient ORDER BY patient_id ASC");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <?php include "header.php"?>
    <?php 
    include "side.php";
    session_start();
    $decide=$_SESSION["token"];
    ?>
    <!--sidebar end-->
 
    <div class="content" id='doc'>
      <div class='top'><button class='but'><a href='homepage.php'>Back</a></button>
      <button class='but' id='sup'><a href='prescribe.php'>Prescription</a></button></div>
    <div class='incontent'>
        <div class='inside'>
        <hr>
        <div class='fcontain'><center>
          <div id="form1">
        <form method = 'post' class = 'form' action = 'patient.php'>

        <input class='in' id='in2' name = 'fname' placeholder='First Name' type='text'>
        <input class='in' id='in2' name = 'lname' placeholder='Last Name' type='text'>
        <input name='gender' class = 'in' id = 'in2' placeholder = 'M/F' type = 'text' required>
            <br><br>
        <input class='in sin' id='in2' name = 'address' placeholder='Address' type='text' required>
        <input class='in sin' id='in2' name = 'phone' placeholder='Phone Number' type='number' required>
        <br><br>
        <input class='in sin' id='in2' name = 'doctor_id' placeholder='Doctor ID' type='number' required>
        <input class='in sin' id='in2' name = 'insr' placeholder='Insurance Info' type='text' required>
      <br>  <input type =  'submit' class = 'reg' value = 'Add' name = 'submit'><br>
      </form></div></center><br><br>
     <center> <input type="search" placeholder="Search" class="inBox3" id="searchInpu" style="color:#000;padding:10px;"><button style="background-color:#000;padding:10px;" class="clear3" id="clear">clear</button></center>

      
      <section>
      <h1><center>PATIENT DETAILS</center></h1>
      <table class="maintable" id="contentDisplay" style="visibility:hidden;">
           <thead>
             <tr>
             <th>Patient ID</th>
            <th>First Name</th>
            <th>Last Name</th> 
            <th>Gender</th>
            <th>Address</th>
            <th>Phone No.</th>
            <th>Doctor Name</th>
             </tr>
             <tr>
               
             </tr>
           </thead>
          </table>
          <p style="color:gray;text-align:center;font-size:20px;" id="error"></p>
      <table class='maintable' id="edit3">
          <tr>
            <th>Patient ID</th>
            <th>First Name</th>
            <th>Last Name</th> 
            <th>Gender</th>
            <th>Address</th>
            <th>Phone No.</th>
            <th>Doctor Name</th>
          </tr>
      <?php 
            while($rows = mysqli_fetch_assoc($res)){
              $did = $rows['doctor_id'];
              $rrows = mysqli_fetch_assoc(mysqli_query($conn,"SELECT first_name,last_name FROM doctor WHERE phy_id = '$did'"));
              $dname = $rrows['first_name'].' '.$rrows['last_name'];
              ?>
          <tr>
            <td><?php echo $rows['patient_id'];?></td>
            <td><?php echo $rows['first_name'];?></td>
            <td><?php echo $rows['last_name'];?></td>
            <td><?php echo $rows['gender'];?></td>
            <td><?php echo $rows['address'];?></td>
            <td><?php echo $rows['phone_no'];?></td>
            <td><?php echo $dname;?></td>
           <!-- <td id="visi"><a href="delete.php?id=<?php echo $rows["patient_id"];?>&&sid=4">Delete</a></td> -->
           
          </tr>
          <?php }?>
        </table></section>
        
        <br>
        </div>   </div>  </div>   

    </div>

    <?php

if($decide==1){
  echo '<script type="text/javascript">
  let sidebar=document.getElementsByClassName("sidebar");
  let form2=document.getElementById("form1");
  form2.style.display="none";
let visi=document.getElementById("visi");
visi.style.display="block";
  for(let i=0;i<6;i++){
  sidebar[0].children[i].style.display="inline-block";
 
}
</script>
';
}
else if($decide==2){
 echo '<script type="text/javascript" src="javascript\none.js">

</script>';
}
else if($decide==3){
  echo '<script type="text/javascript" src="javascript\none2.js">

</script>';
echo '<script type="text/javascript">
let form=document.getElementById("form1");
form.style.display="none";
</script>';
}
?> 
  </body>
  <script src="javascript/onclick.js"></script>
</html>
