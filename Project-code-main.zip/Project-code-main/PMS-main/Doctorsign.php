<?php
$conn = mysqli_connect("localhost","root","","pharmacy2");
if(!$conn){
  die("Connection to the database lost...".mysqli_connect_error());
}
if(isset($_POST['submit'])){
  $iid=rand(10,100);
  $fname = $_POST['fname'];
  $lname = $_POST['lname'];
  $special = $_POST['speciality'];
  $sql = "SELECT * FROM doctor WHERE (phy_id=$iid)";
  $res = mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)){
    echo"<script type = 'text/javascript'> 
      alert('Username already exists...');</script>";
  }
  else{
    $sql = "INSERT INTO doctor(phy_id,first_name,last_name,speciality) VALUES($iid,'$fname','$lname','$special')";
    if(mysqli_query($conn,$sql)){
      $pass=rand(100,999)."£%".rand(100,999);
      $sql2= "INSERT INTO doctor_log(id,doctor_id,password) VALUES(null,$iid,'$pass')";
      mysqli_query($conn,$sql2);
      echo"<script type = 'text/javascript'> 
      alert('Given Details have been added successfully...');</script>";
      header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/Doctorsign.php");
    }
    else{
      echo"<script type = 'text/javascript'> 
      alert('Failed to enter given details...');</script>";
    }
  }
}
$res = mysqli_query($conn,"SELECT * FROM doctor ORDER BY phy_id ASC");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <?php include "header.php"?>
    <?php
session_start();
include "side.php";
$decide=$_SESSION["token"];
?>  
     
      <div class="content" id='doc'>
        <div class='incontent'>
        <div class='inside'>
        <div class='top'><button class='but'><a href='homepage.php'>Back</a></button></div>
        <hr>
        <div class='fcontain'>
          <center>
        <form method = 'post' action = 'Doctorsign.php' class = 'form'>
        <div><input class='in fin' placeholder='First Name' type='text' name = 'fname' required></div>
        <div><input class='in sin' placeholder='Last Name' type='text' name = 'lname' required></div>
        <div><select name="speciality" class="in fin" required>
          <label>Speciality</label>
          <option selected disabled>Speciality</option>
          <option>Phyisician</option>
          <option>Surgeon</option>
          <option>Gynaecologist</option>
          <option>Cardiologist</option>
        </select></div>
        <input type =  'submit' class = 'reg' value = 'Add' name = 'submit'><br>
        </form><br><br>
        <input type="search" placeholder="Search" class="inBox1" id="searchInpu" style="color:#000;padding:10px;"><button style="background-color:#000;padding:10px;" class="clear1" id="clear">clear</button>
        <section>
          <h1><center>DOCTOR DETAILS</center></h1>
          <table class="maintable" id="contentDisplay" style="visibility:hidden;">
           <thead>
             <tr>
             <th>Phy_ID</th>
            <th>First Name</th>
            <th>Last Name</th> 
            <th>Speciality</th>
             </tr>
             <tr>
               
             </tr>
           </thead>
          </table>
          <p id="error" style="color:gray;text-align:center;font-size:20px;"></p>
        <table class='maintable' id="edit1">
          <tr>
            <th>Phy_ID</th>
            <th>First Name</th>
            <th>Last Name</th> 
            <th>Speciality</th>
          </tr>
          <?php 
            if($res)
            while($rows = mysqli_fetch_assoc($res)){
              ?>
          <tr>
            <td><?php echo $rows['phy_id'];?></td>
            <td><?php echo $rows['first_name'];?></td>
            <td><?php echo $rows['last_name'];?></td>
            <td><?php echo $rows['speciality'];?></td>           
          </tr>
          <?php } ?>
        </table></section>
        </center>
        <br>
        </div>   
      </div>  
    </div>   
    </div>
    <?php
    if($decide==1){
      echo '<script type="text/javascript>
      let sidebar=document.getElementsByClassName("sidebar");
      let visi=document.getElementById("visi");
    visi.style.display="block";
    for(let i=0;i<6;i++){
     
      sidebar[0].children[i].style.display="inline-block";
    }</script>';
    }
    else if($decide==2){
     echo '<script type="text/javascript" src="javascript/none.js">
    
    </script>';
    echo '<script type="text/javascript">
    let form=document.getElementById("form2");
    form.style.display="none";
    </script>';
    }
    else if($decide==3){
      echo '<script type="text/javascript" src="javascript/none2.js">
    
    </script>';

    }
    ?>
  </body>
  <script src="javascript/onclick.js"></script>
</html>
