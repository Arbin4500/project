<!DOCTYPE html>
<html>
    <head></head>
<body>
<?php
echo "<p style='color:red;'>Sorry only admin can sign up</p>";

?>
<br>
<button style="background-color:red;color:white;padding:10px 30px;border-radius:10px;"><a href="login.php" style="color:white;text-decoration:none;" >Go Back</a></button>
</body>


</html>