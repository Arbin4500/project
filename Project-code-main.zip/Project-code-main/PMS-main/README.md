# Patient Record Management System (a Website)
an open source project created using PHP for frontend developement and MySQL for backend development
