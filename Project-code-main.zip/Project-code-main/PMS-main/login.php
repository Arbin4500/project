<?php
if(isset($_POST['verify'])){
  $choose=$_POST['choose'];
  if($choose=="Yes"){
    header("Location:signup.php");
  }
  else{
    header("Location:medium.php");
  }
}
$conn = mysqli_connect("localhost","root","","flight_booking");
if(!$conn){
  die("Connection to the database lost...".mysqli_connect_error());
}
if(isset($_POST['submit'])){
  $username = $_POST['username'];
  $password = $_POST['password'];
  $Usertype=$_POST['userType'];
  $username=mysqli_real_escape_string($conn,$username);
  $password=mysqli_real_escape_string($conn,$password);
  if(strcmp($Usertype,"Admin")==0){
    $result = mysqli_query($conn,"SELECT * FROM admin WHERE username = '$username' and password = '$password'");
    }
      else if(strcmp($Usertype,"User")==0){
        $username =(int)$_POST['username'];
        $result = mysqli_query($conn,"SELECT * FROM user_tbl WHERE patient_id=$username and password = '$password'");
        }
  if(mysqli_num_rows($result)>0){
    session_start();
    $_SESSION["logged_in"] = true;
    if(strcmp($Usertype,"Admin")==0){
      header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/homepage.php?token=1");

    }
      else if(strcmp($Usertype,"Doctor")==0){
        header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/homepage.php?token=2");

      }
        else if(strcmp($Usertype,"Patient")==0){
          header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/homepage.php?token=3");
        }
  }
  else{
    echo '<script type = "text/javascript">
    alert("Incorrect Username or Password...");</script>';
}
}

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Login | XYZ Patient Record Management System</title>
    <link rel="stylesheet" href="CSS/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css">
    <script src="https://kit.fontawesome.com/0cc63ebc07.js" crossorigin="anonymous"></script>

  </head>
  <body>

   
    <!--sidebar end-->

    <div class="content" id='log'>

    <div class='top'><button class='but'><a href='index.php'>Back</a></button></div>
    <hr>
      <center> 
      <h1>Log in</h1>
       <form class = 'form' method = 'post' action = 'login.php'>
          <input name = 'username' class = 'fin in' type = 'text' placeholder = 'Username' required><br>
          <input name = 'password' class = 'Tin in' type = 'password' placeholder = 'Password' required><br>
          <select style="background-color:black; padding:10px 20px;" name="userType" id="UserType">
            <option value="Select..." disabled selected>Select...</option>
            <option value='Admin'>Admin</option>
            <option value='User'>User</option>
            
          </select>
         
          <br>
          <input name = 'submit' class = 'reg' type = 'submit' value = "Login"><br>
        </form>
       </form>
  
       
  </center>
    </div>

  </body>
</html>