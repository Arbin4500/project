<?php
$conn = mysqli_connect("localhost","root","","pharmacy2");
if(!$conn){
  die("Connection to the database lost...".mysqli_connect_error());
}
if(isset($_POST['submit'])){
  $drug = (int)$_POST['drug'];
  $patient = (int)$_POST['patient'];
  $quant = (int)$_POST['quant'];
  $sql = "SELECT * FROM presc WHERE patient_pre_id = '$patient' AND drug_pre_id = '$drug'";
  $res = mysqli_query($conn,$sql);
  if(mysqli_num_rows($res)){
    echo"<script type = 'text/javascript'> 
      alert('Data already exists...');</script>";
  }
  else{
    $s = mysqli_fetch_assoc(mysqli_query($conn,"SELECT doctor_id FROM patient WHERE patient_id =$patient"));
    $p = $s['doctor_id'];
    $sql = "INSERT INTO presc(patient_pre_id,drug_pre_id,doctor_pre_id,date,quantity) VALUES ('$patient','$drug','$p',curdate(),'$quant')";
    if(mysqli_query($conn,$sql)){
      echo"<script type = 'text/javascript'> 
      alert('Given Details have been added successfully...');</script>";
      header("location:http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/prescribe.php");
    }
    else{
      echo"<script type = 'text/javascript'> 
      alert('Failed to enter given details...');</script>";
    }
  }
}
$res = mysqli_query($conn,"SELECT * FROM presc ORDER BY patient_pre_id ASC");
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
 <?php include "header.php" ?>
    <?php
session_start();
include "side.php";
$decide=$_SESSION["token"];

?> 
    <!--sidebar end-->

    <div class="content" id='doc'>
       
            <div class='incontent'>
                <div class='inside'>
                <div class='top'><button class='but'><a href='patient.php'>Back</a></button></div>
                <hr>
                <div class='fcontain' id="form1"><center><div><h3>Prescriptions</h3></div>
                <div>
                <form method ='post' class = 'form' action = 'prescribe.php'>
                <input class='in sin' id='in2' placeholder='Patient Id' type='Number' name = 'patient' required>
                <input class='in sin' id='in2' placeholder='Drug Id' type='Number' name = 'drug' required>
                <input class='in sin' id='in2' placeholder='quantity' type='Number' name = 'quant' required>
              
              <br>  <input class='reg' type = 'submit' name = 'submit' value = 'Add'>
                <br><br>
              </form></div></center>
              </div>
              </form><br><br>
              <center> <input type="search" placeholder="Search" class="inBox4" id="searchInpu" style="color:#000;padding:10px;"><button style="background-color:#000;padding:10px;" class="clear4" id="clear">clear</button></center>
<br>
              <section>
                <center><h1>PRESCRIPTION DETAILS</h1>
                <table class="maintable" id="contentDisplay" style="visibility:hidden;">
           <thead>
             <tr>
             <th>Patient ID</th>
            <th>First Name</th>
            <th>Last Name</th> 
            <th>Gender</th>
            <th>Address</th>
            <th>Phone No.</th>
            <th>Doctor Name</th>
             </tr>
             <tr>
               
             </tr>
           </thead>
          </table>
          <p style="color:gray;text-align:center;font-size:20px;" id="error"></p>
          <table class='maintable' id="edit4">
          <tr>
            <th>PID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Drug Name</th> 
            <th>Doctor Name</th>
            <th>Date</th>
            <th>Quantity</th>
          </tr>
          <?php 
            while($rows = mysqli_fetch_assoc($res)){
              ?>
          <tr>
            <td><?php echo $rows['patient_pre_id'];?></td>
            <?php
             $pid = $rows['patient_pre_id'];
             $drid = $rows['drug_pre_id'];
             $did = $rows['doctor_pre_id'];
             $prows = mysqli_fetch_assoc(mysqli_query($conn,"SELECT first_name,last_name FROM patient WHERE patient_id = '$pid'"));
             $qrows = mysqli_fetch_assoc(mysqli_query($conn,"SELECT drug_name FROM drug WHERE drug_id = '$drid'"));
             $rrows = mysqli_fetch_assoc(mysqli_query($conn,"SELECT first_name,last_name FROM doctor WHERE phy_id = '$did'"));
             $dname = $rrows['first_name'].' '.$rrows['last_name'];
             ?>
            <td><?php echo $prows['first_name'];?></td>
            <td><?php echo $prows['last_name'];?></td>
            <td><?php echo $qrows['drug_name'];?></td>
            <td><?php echo $dname;?></td>
            <td><?php echo $rows['date'];?></td>
            <td><?php echo $rows['quantity'].' gm';?></td>
            <td><a href="delete.php?id=<?php echo $rows['patient_pre_id'];?>&&sid=5">Delete</a></td>

          </tr>
          <?php } ?>
  </table>
  </section>
</center>
                <br>
                </div>   </div>  </div>   
       
       
        
            </div>
           <?php if($decide==1){
  echo '<script type="text/javascript">
  let sidebar=document.getElementsByClassName("sidebar");
  let form=document.getElementById("form1");
  form.style.display="none";
for(let i=0;i<6;i++){
  sidebar[0].children[i].style.display="inline-block";
}</script>';
}
else if($decide==2){
 echo '<script type="text/javascript" src="javascript\none.js">

</script>';
}
else if($decide==3){
  echo '<script type="text/javascript" src="javascript\none2.js">

</script>';
echo '<script type="text/javascript">
let form=document.getElementById("form1");
form.style.display="none";
</script>';
} ?>
  </body>
  <script type="text/javascript" src="javascript/onclick.js"></script>
</html>
