<div class="content" id='marg'>
   <?php
   include "menu.php";
   ?>
    </div>