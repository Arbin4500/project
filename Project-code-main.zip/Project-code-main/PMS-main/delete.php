<!DOCTYPE html>
<html>
<?php include "header.php"?>
    <?php
    include "side.php";
    ?>
     <div class="content" id='doc'>
        <div class='incontent'>
        <div class='inside'>
        <div class='top'><button class='but'><a href='homepage.php'>Back</a></button></div>
        <hr>
        <div class='fcontain'>
          <center>
    <form class="form" action="delete.php" method="GET">
    <div><select name="ut" class="in fin" required>
          <option selected>Select the Subject</option>
          <option value="Doctor">Doctor</option>
          <option value="Patient">Patient</option>
          <option value="Drug">Drug</option>
        </select></div>
<br>
<div class='fdiv'><input name = 'uid' class='in fin' placeholder='Subject id to be deleted' type='number' required></div>
<br>
<input type = 'submit' name = 'sub' class = 'reg' value = 'delete'><br>

</form>
<p id="error"></p>
</center>
</div>
</div>
</div>
<?php
$conn = mysqli_connect("localhost","root","","pharmacy2");
if(isset($_GET['sub'])){
    $decide=$_GET['ut'];
 if(strcmp($decide,"Doctor")==0){
        
        $id=(int)$_GET['uid'];
        
        $sql="DELETE FROM doctor WHERE phy_id=$id;";
       $result=mysqli_query($conn,$sql);
echo "hello";
   header("Location:delete.php");
    }
    else if(strcmp($decide,"Patient")==0){
      
        $id=(int)$_GET['uid'];
        
        $sql="DELETE FROM patient WHERE patient_id=$id;";
       $result=mysqli_query($conn,$sql);
echo "hello";
   header("Location:delete.php");
    }
    else if(strcmp($decide,"Drug")==0){
        $id=(int)$_GET['uid'];
        
        $sql="DELETE FROM drug WHERE drug_id=$id;";
       $result=mysqli_query($conn,$sql);
echo "hello";
   header("Location:delete.php");
    }
    else{
      echo '<script type="text/javascript">
      let err=document.getElementById("error");
      err.textContent="invalid subject";
      </script>';
    }
}
?>
</body>
</html>