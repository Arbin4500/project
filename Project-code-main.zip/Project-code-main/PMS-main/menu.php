<?php
$conn =new  mysqli("localhost","root","","flight_booking");
$sql="SELECT * from cities;";
$result=$conn->query($sql);
while($row=$result->fetch_assoc()){
    
}
?>
<nav>

<h1>One Way</h1>
<form action="" method="post" >
    <label for="">Departure City</label>
    <br>
    <select style="background-color:black; padding:10px 20px;" name="userType" id="UserType">
         <option value="">ksjldfkj</option>
         <option value="">ksjldfkj</option>
         <option value="">ksjldfkj</option>

          </select>
</form>
</nav>