console.log("hello");
let sidebar=document.getElementsByClassName("sidebar");

for(let i=0;i<6;i++){
if(i==0 || i==3){
   
 continue;
}
else{
sidebar[0].children[i].style.display="none";
}

}
