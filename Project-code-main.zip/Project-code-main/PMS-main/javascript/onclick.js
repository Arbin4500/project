  let table1 = document.getElementById("edit1");
let table2 = document.getElementById("edit2");
let table3 = document.getElementById("edit3");
let table4 = document.getElementById("edit4");
let a;
let err=document.getElementById("error");
let clear = document.getElementById("clear");
let searchInput = document.getElementById("searchInpu");
let contentDisplay = document.getElementById("contentDisplay");
clear.addEventListener("click", (e) => {
    searchInput.value = "";
    
    if (e.target.className == "clear1") {
        table1.style.visibility = "visible";
        error.textContent="";
        count=0;

    }
    else if (e.target.className == "clear2") {
        table2.style.visibility = "visible";
        error.textContent="";
        count=0;
        
    }
    else if (e.target.className == "clear3") {
        table3.style.visibility = "visible"; 
        error.textContent="";
        count=0;
        
    }
   else if (e.target.className == "clear4") {
    table4.style.visibility = "visible"; 
    error.textContent="";
    count=0;
        
    }
    
    contentDisplay.children[0].children[1].innerHTML = "";
    contentDisplay.style.visibility = "hidden";
});
// let b;
// let c;
// for(let i=1;i<a.length;i++){
//     b=a[i].getElementsByTagName("td"); 

// console.log(b[0].textContent);

// }
let count = 0;
let temp;
function recursion(a, searchValue, start, end) {
    count=0;
    contentDisplay.children[0].children[1].innerHTML = "";
    contentDisplay.style.visibility = "hidden";
while(1){
    //  let middle=Math.floor((start+end)/2);
    //  console.log(middle);
    //  console.log(searchValue);
    //  console.log(a[middle].children[0].textContent);
    //   if(parseInt(a[middle].children[0].textContent)<searchValue){
    // start=middle+1;
    // }
    // console.log(start);
    // middle=Math.floor((start+end)/2);
    // console.log(middle);
    // console.log(searchValue);
    // console.log(a[middle].children[0].textContent==searchValue);
    count++;
    let middle = Math.floor((start + end) / 2);
    if (parseInt(a[middle].children[0].textContent) == searchValue) {
        contentDisplay.style.visibility = "visible";
        for (let i = 0; i < a[middle].children.length; i++) {
            console.log("this may times"+i);
            contentDisplay.children[0].children[1].innerHTML += `<td>${a[middle].children[i].textContent}</td>`;
        
        }
        error.textContent="";
        break;
        //   a[middle].style.visibility="visible";
    }
//     else if(count>a.length){
// return 0;
//     }
    else if (parseInt(a[middle].children[0].textContent) > searchValue) {
                    end=middle-1;
        // recursion(a, searchValue, start, middle - 1);
    }
    else if (parseInt(a[middle].children[0].textContent) < searchValue) {
        start=middle+1
        // recursion(a, searchValue, middle + 1, end);
    }   
    if(count>a.length){
        error.textContent="No result.....";
      break;  
    }
}
}
searchInput.addEventListener("keyup", (e) => {
    console.log("hello0");
    let searchValue = parseInt(document.getElementById("searchInpu").value.trim());

    if (e.target.className == "inBox1") {
       a = table1.getElementsByTagName("tr");   
       table1.style.visibility = "hidden";
    }
    else if (e.target.className == "inBox2") {
        console.log("hello2");

         a = table2.getElementsByTagName("tr");
        table2.style.visibility = "hidden";
    }
    else if (e.target.className == "inBox3") {
        console.log("hello3");

         a = table3.getElementsByTagName("tr");
        table3.style.visibility = "hidden";
    }
   else if (e.target.className == "inBox4") {
    console.log("hello4");

         a = table4.getElementsByTagName("tr");
        table4.style.visibility = "hidden";
    }

    // for(let i=1;i<a.length;i++){
    //     a[i].style.visibility="hidden";
    // }
    recursion(a, searchValue, 1, (a.length - 1));
});