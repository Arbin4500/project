<!DOCTYPE html>
<html lang="en" dir="ltr">
  <?php include "header.php";?>
<?php
session_start();
include "side.php";
if(isset($_GET["token"])){
  
$_SESSION["token"]=$_GET["token"];

}
$decide=$_SESSION["token"];
echo $decide;
if($decide==1){
  echo 'let sidebar=document.getElementsByClassName("sidebar");
for(let i=0;i<6;i++){
  else{
  sidebar[0].children[i].style.display="inline  ";
}
}';
}
else if($decide==2){
 echo '<script type="text/javascript" src="javascript\none.js">

</script>';
}
else if($decide==3){
  echo '<script type="text/javascript" src="javascript\none2.js">

</script>';
}
?> 

    <!--sidebar end-->

   <?php include "header2.php"?>
  </body>
</html>
